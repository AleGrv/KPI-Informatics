
/* FUNCTIONS DECLARATION */

void f_creator();
void expr_w(int N, double X1, double X2, double delta, char gr_code[10], char st_name[20]);
void bin_r(int N, char gr_code[10], char st_name[20]);
